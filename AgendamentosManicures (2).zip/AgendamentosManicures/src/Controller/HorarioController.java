package Controller;

import javax.swing.JOptionPane;
import modelo.Horario;
import modelo.HorarioRepository;


public class HorarioController {
    
    private HorarioRepository repository;
    
    public HorarioController(){
        repository = new HorarioRepository();
    }
    public boolean cadastraHorario(Horario novoHorario){
        
        
        if(novoHorario == null){
            return false;
        }
        if(novoHorario.getHora() == null){
            
            JOptionPane.showMessageDialog(null, novoHorario.getHora());
            
        }
        if(novoHorario.getDiaSemana() == null || novoHorario.getData() == null || novoHorario.getHora() == null){
            return false;
        }
        
        System.out.println("HEREEEE");
        HorarioRepository repository = new HorarioRepository();
        //repository.insereNovoHorario(novoHorario);
        boolean retornoBD = repository.insereNovoHorario(novoHorario);
        
        return retornoBD;
    }
}