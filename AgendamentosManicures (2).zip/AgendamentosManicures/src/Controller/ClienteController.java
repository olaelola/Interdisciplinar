//classe controller responsável pela lógica da minha aplicação
//base de dados é no repository
package Controller;

import modelo.Cliente;
import modelo.ClienteRepository;


public class ClienteController {
    
    private ClienteRepository repository;
    
    public ClienteController(){
        repository = new ClienteRepository();
    }
    public boolean cadastraCliente(Cliente novoCliente){
        
        //verificando os dados do novo filme
        if(novoCliente == null){
            return false;
        }
        if(novoCliente.getPreferencias().isEmpty() || novoCliente.getObservacoes().isEmpty()){
            return false;
        }
        
        ClienteRepository repository = new ClienteRepository();
        repository.insereNovoCliente(novoCliente);
        boolean retornoBD = repository.insereNovoCliente(novoCliente);
        
        return retornoBD;
    }
}
