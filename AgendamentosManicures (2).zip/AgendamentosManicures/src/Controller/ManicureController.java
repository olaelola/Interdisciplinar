
package Controller;

import modelo.Manicure;
import modelo.ManicureRepository;


public class ManicureController {
    
    private ManicureRepository repository;
    
    public ManicureController(){
        repository = new ManicureRepository();
    }
    public boolean cadastraManicure(Manicure novaManicure){
        
        
        if(novaManicure == null){
            return false;
        }
        if(novaManicure.getEspecialidade().isEmpty() || novaManicure.getNome().isEmpty() || novaManicure.getTelefone().isEmpty() || novaManicure.getEndereco().isEmpty() ||novaManicure.getEmail().isEmpty() || novaManicure.getSenha().isEmpty()){
            return false;
        }
        
        ManicureRepository repository = new ManicureRepository();
        repository.insereNovaManicure(novaManicure);
        boolean retornoBD = repository.insereNovaManicure(novaManicure);
        
        return retornoBD;
    }
}
