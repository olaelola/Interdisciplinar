
package Controller;

import modelo.Pagamento;
import modelo.PagamentoRepository;


public class PagamentoController {
    
    private PagamentoRepository repository;
    
    public PagamentoController(){
        repository = new PagamentoRepository();
    }
    public boolean cadastraPagamento(Pagamento novoPagamento){
        
        //verificando os dados do novo pagamento
        if(novoPagamento == null){
            return false;
        }
        if(novoPagamento.getValorSinal()!= 0 || novoPagamento.getValorTotal() != 0 || novoPagamento.getFormaPagamento().isEmpty() || novoPagamento.getDataPagamento().isEmpty()){
            return false;
        }
        
        PagamentoRepository repository = new PagamentoRepository();
        repository.insereNovoPagamento(novoPagamento);
        boolean retornoBD = repository.insereNovoPagamento(novoPagamento);
        
        return retornoBD;
    }
}
