//classe controller responsável pela lógica da minha aplicação
//base de dados é no repository
package Controller;

import modelo.Alarme;
import modelo.AlarmeRepository;


public class AlarmeController {
    
    private AlarmeRepository repository;
    
    public AlarmeController(){
        repository = new AlarmeRepository();
    }
    public boolean cadastraFilme(Alarme novoAlarme){
        
        
        if(novoAlarme == null){
            return false;
        }
        if(novoAlarme.getHoraUnha().isEmpty() || novoAlarme.getLocalAtendimento().isEmpty()){
            return false;
        }
        
        AlarmeRepository repository = new AlarmeRepository();
        repository.insereNovoAlarme(novoAlarme);
        boolean retornoBD = repository.insereNovoAlarme(novoAlarme);
        
        return retornoBD;
    }
}
