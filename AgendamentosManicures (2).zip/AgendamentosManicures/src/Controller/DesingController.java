
package Controller;

import modelo.Desing;
import modelo.DesingRepository;


public class DesingController {
    
    private DesingRepository repository;
    
    public DesingController(){
        repository = new DesingRepository();
    }
    public boolean cadastraDesing(Desing novoDesing){
        
        
        if(novoDesing == null){
            return false;
        }
        if(novoDesing.getModelo().isEmpty() || novoDesing.getFormato().isEmpty() || novoDesing.getTipo().isEmpty()){
            return false;
        }
        
        DesingRepository repository = new DesingRepository();
        repository.insereNovoDesing(novoDesing);
        boolean retornoBD = repository.insereNovoDesing(novoDesing);
        
        return retornoBD;
    }
}


