
package gui;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import modelo.Horario;


public class RegrasTabelaHorario extends AbstractTableModel {
    
    private Vector<Horario> horarios;
    private String cabecalho[] = {"diaSemana", "data", "hora"};
    
    public RegrasTabelaHorario(){
        this.horarios = new Vector<>();
         carregaHorarios();
        
    }
    private void carregaHorarios(){
        //mais pra frenre invocar o controler p buscar um horario
        this.horarios.add(new Horario("Sábado", "21/01/2023", "09:00", true));
        this.horarios.add(new Horario("Segunda-feira", "15/02/2023","10:30", false));
    }

    //n de linhas
    @Override
    public int getRowCount() {
        return this.horarios.size();
    }
    //n de coluna
    @Override
    public int getColumnCount() {
        return 4;
    }
    //passa por todas as posições
    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Horario HorarioTemp = this.horarios.get(indiceLinha);
        
        switch(indiceColuna){
            case 0: return HorarioTemp.getDiaSemana();
                //DiaSemana
            case 1: return HorarioTemp.getData();
                //Data
            case 2: return HorarioTemp.getHora();
                //Hora
            case 3: return HorarioTemp.isReservado();
                //Reservado
                    default: return null;
        }
    }

    @Override
    public String getColumnName(int indiceColuna) {
        return cabecalho [indiceColuna];
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        return true;
    }
    //modifica info
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        Horario HorarioModificar = this.horarios.get(indiceLinha);
        
        switch(indiceColuna){
            case 0: 
                HorarioModificar.setDiaSemana((String)novoValor); break;
            case 1: 
                HorarioModificar.setData((String)novoValor); break;
            case 2: 
                HorarioModificar.setHora((String)novoValor); break;
            case 3: 
                HorarioModificar.setReservado((boolean)novoValor); break;
        }
        
    }
    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        switch(indiceColuna){
            case 2: return Integer.class;
            case 4: return Boolean.class;
            default: return String.class;
        }
    }
    public void addNovoHorario(Horario novo){
        this.horarios.add(novo);
        
    }
    
    
    
}
