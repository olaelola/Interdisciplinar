
package gui;

import Controller.ClienteController;
import Controller.HorarioController;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import modelo.Horario;
import gui.PanelPagamento;


public class PanelHorários extends javax.swing.JPanel {
    
    private RegrasTabelaHorario minhasRegras;
    
    private HorarioController controllerH = new HorarioController();
    
    private FrameCadastro framePai; 
    
    private String diaSemana;
    private String data;
    private String hora;
    private boolean reservado;


    public PanelHorários(FrameCadastro framePai) {
        initComponents();
        this.framePai=framePai;
    }
    /*/@Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);
        
        try {  
            //carregando a imagem de fundo
            Image imagemFundo = ImageIO.read(
                    new File(getClass().
                            getResource("/imagens/imagem_fundo.jpg").
                            getFile()));
            
            //redimen. uma imagem
            imagemFundo = imagemFundo.getScaledInstance(600, 400, 
                    Image.SCALE_DEFAULT);
            
            //"pintando" a imagem no painel
            g.drawImage(imagemFundo, 0, 0, this);
            
            
        } catch (IOException ex) {
            System.err.println("o arquivo esta corrompido");
        }
                
        
    }/*/

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AgendarBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        HoráriosTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        diaSemanaTxt = new javax.swing.JTextField();
        dataTxt = new javax.swing.JTextField();
        HoraTxt = new javax.swing.JTextField();
        ReservadoButton = new javax.swing.JRadioButton();

        AgendarBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        AgendarBtn.setForeground(new java.awt.Color(153, 153, 0));
        AgendarBtn.setText("Agendar horário");
        AgendarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgendarBtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 0));
        jLabel2.setText("Nail Designer");

        HoráriosTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(HoráriosTable);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Dia da semana:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Data:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Hora:");

        diaSemanaTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diaSemanaTxtActionPerformed(evt);
            }
        });

        dataTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataTxtActionPerformed(evt);
            }
        });

        ReservadoButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ReservadoButton.setText("Reservado");
        ReservadoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservadoButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(ReservadoButton)
                    .addComponent(diaSemanaTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                    .addComponent(dataTxt)
                    .addComponent(HoraTxt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
            .addGroup(layout.createSequentialGroup()
                .addGap(274, 274, 274)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AgendarBtn)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(diaSemanaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dataTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HoraTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ReservadoButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(AgendarBtn)
                .addGap(55, 55, 55))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void AgendarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgendarBtnActionPerformed
    if(diaSemanaTxt.getText().isEmpty() || dataTxt.getText().isEmpty() || HoraTxt.getText().isEmpty()){
            
            //mens. para não preenchimento de todas as caract. do agendamento
            JOptionPane.showMessageDialog(this, 
                    "É necessário preencher todos os campos",
                    "preenchimento dos campos",
                    JOptionPane.WARNING_MESSAGE);
        }else{
            //campos devidamente preenchidos
            
            String diaSemana = diaSemanaTxt.getText();
            String data = dataTxt.getText();
            String Hora = HoraTxt.getText();
            
            //tentativa
                
                //criando um novo agendamento
                Horario novoHorario = new Horario(diaSemana, data, 
                        hora, ReservadoButton.isSelected());

                boolean sucesso = controllerH.cadastraHorario(novoHorario);
                
                //atual. a interface se o cadastro na base teve sucesso
                if(sucesso == true){
                    this.minhasRegras.addNovoHorario(novoHorario);

                    //força a tabela da interface grafica ser atual.
                    HoráriosTable.updateUI();
                    
                    this.framePai.trocarPainel(new PanelPagamento(this.framePai));
                }else{
                    JOptionPane.showMessageDialog(this, "Erro no cadastro", "Mensagem do Sistema", JOptionPane.WARNING_MESSAGE);
                }
            
            
            
        }
    }//GEN-LAST:event_AgendarBtnActionPerformed

    private void diaSemanaTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diaSemanaTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diaSemanaTxtActionPerformed

    private void dataTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dataTxtActionPerformed

    private void ReservadoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservadoButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ReservadoButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgendarBtn;
    private javax.swing.JTextField HoraTxt;
    private javax.swing.JTable HoráriosTable;
    private javax.swing.JRadioButton ReservadoButton;
    private javax.swing.JTextField dataTxt;
    private javax.swing.JTextField diaSemanaTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
