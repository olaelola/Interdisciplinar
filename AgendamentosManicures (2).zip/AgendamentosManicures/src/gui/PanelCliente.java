package gui;

import Controller.ClienteController;
import static gui.FrameCadastro.emailUsuario;
import static gui.FrameCadastro.endereçoUsuario;
import static gui.FrameCadastro.senhaUsuario;
import static gui.FrameCadastro.telefoneUsuario;
import java.awt.Dialog;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import modelo.Cliente;
import modelo.Usuario;
import gui.PanelHorários;

public class PanelCliente extends javax.swing.JPanel {

    private ClienteController controllerC = new ClienteController();

    private FrameCadastro framePai;

    private String preferencias;
    private String observacoes;
    private boolean alergia;

    public PanelCliente(FrameCadastro framePai) {
        initComponents();

        this.framePai = framePai;

    }

    /*/@Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);
        
        try {  
            //carregando a imagem de fundo
            Image imagemFundo = ImageIO.read(
                    new File(getClass().
                            getResource("/imagens/imagem_fundo.jpg").
                            getFile()));
            
            //redimen. uma imagem
            imagemFundo = imagemFundo.getScaledInstance(600, 400, 
                    Image.SCALE_DEFAULT);
            
            //"pintando" a imagem no painel
            g.drawImage(imagemFundo, 0, 0, this);
            
            
        } catch (IOException ex) {
            System.err.println("o arquivo esta corrompido");
        }
                
        
    }/*/

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AlergiaBtn = new javax.swing.JRadioButton();
        ButtonHorários = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        entradaObservacoesC = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        entradaNomeC = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        entradaPreferenciasC = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(569, 406));

        AlergiaBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        AlergiaBtn.setText("Alergia?");

        ButtonHorários.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        ButtonHorários.setForeground(new java.awt.Color(153, 153, 0));
        ButtonHorários.setText("Ver horários disponíveis ");
        ButtonHorários.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonHoráriosActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Nome:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Preferências:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Observações:");

        jScrollPane1.setViewportView(entradaObservacoesC);

        jScrollPane2.setViewportView(entradaNomeC);

        jScrollPane3.setViewportView(entradaPreferenciasC);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 0));
        jLabel5.setText("Nail Designer");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(AlergiaBtn)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel1))
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(297, 297, 297)
                        .addComponent(ButtonHorários)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(288, 288, 288)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(270, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addComponent(AlergiaBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(ButtonHorários)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(46, 46, 46)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(426, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonHoráriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonHoráriosActionPerformed
        if (entradaNomeC.getText().isEmpty() || entradaPreferenciasC.getText().isEmpty() || entradaObservacoesC.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "É necessário preencher todos os campos", "Prrenchimento dos campos", JOptionPane.WARNING_MESSAGE);
        } else {

            String preferenciasUsuarioC = entradaPreferenciasC.getText();
            String observacoesUsuarioC = entradaObservacoesC.getText();

            Cliente novoCliente = new Cliente(preferenciasUsuarioC, observacoesUsuarioC, FrameCadastro.nomeUsuario, FrameCadastro.telefoneUsuario,
                    FrameCadastro.endereçoUsuario, FrameCadastro.emailUsuario, FrameCadastro.senhaUsuario);
            if (AlergiaBtn.isSelected()) {

                boolean sucesso = controllerC.cadastraCliente(novoCliente);

                if (sucesso) {
                    this.framePai.trocarPainel(new PanelHorários(this.framePai));

                } else {
                    //JOptionPane.showMessageDialog(this, "Não foi possivel realizar o cadastro", "Erro no cadastro", JOptionPane.WARNING_MESSAGE);
                }

            }
        }
    }//GEN-LAST:event_ButtonHoráriosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton AlergiaBtn;
    private javax.swing.JButton ButtonHorários;
    private javax.swing.JTextPane entradaNomeC;
    private javax.swing.JTextPane entradaObservacoesC;
    private javax.swing.JTextPane entradaPreferenciasC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
