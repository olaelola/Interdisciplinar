
package dados;

import java.util.Vector;
import modelo.Alarme;
import modelo.Cliente;
import modelo.Desing;
import modelo.Horario;
import modelo.Manicure;


public class FakeBancoDados {
    private static Vector<Manicure> Manicure = new Vector<>();
    private static Vector<Cliente> Cliente = new Vector<>();
    private static Vector<Horario> Horario = new Vector<>();

    public static void iniciaFakeBancoDados() {
       
}
    public static void insereManicure(){

        Horario hora[] = {new Horario("Segunda", "15/01/2022", "09:30", false),
                          new Horario("Sábado", "20/11/2022", "08:00", false),
                          new Horario("Quarta", "02/12/2022", "16:00", false)};
                           
        
        Manicure Eliane  = new Manicure ("Nail Design Internacional", true, "Eliane Magalhães", "3762-8686", "Rua Laranjeiras", "eliane@gmail.com", "ABC123");
        Manicure Jhenny = new Manicure("Curso Manicure Diamante", false, "Jhenny Santos", "3763-8856", "Avenida Professor Emanuel", "jhenny@gmail.com", "apolo2020");
        Manicure Ana = new Manicure("Curso Manicure Faby", false, "Ana Cecília", "377-8686", "Rua General", "aninha@gmail.com", "moodle1515");
       
    }
    
    public static Vector<Horario> SelectAllHorarios(){
        return Horario;
    }
    
   public static void CadastroManicure(Manicure novaManicure){
        Manicure.add(novaManicure);
    }
   public static void CadastroCliente(Cliente novaCliente){
        Cliente.add(novaCliente);
    }
    public static Vector<Horario> getHorario() {
        return null;
    }
    public static void CadastroHorario(Horario novoHorario){
        Horario.add(novoHorario);
    }
    public static void removeHorario(Horario horarioConcluido){
        Horario.remove(Horario);
    }
    public static void consultaHorario(){
        
        int i = 1;
        for(Horario h: Horario){
            System.out.println(i + "° Horario: " + h);
            i++;
        }
    }
        
 }
    