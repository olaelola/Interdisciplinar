
package modelo;

//classe controler responsável pela lógica da minha aplicação

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//classe dao representa 
public class AlarmeRepository {

    public boolean insereNovoAlarme(Alarme novoAlarme) {
        String sql = "INSERT INTO TableAlarme(HoraUnha, LocalAtendimento) "
                + " VALUES(?, ?, ?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novoAlarme.getHoraUnha());
            transacao.setString(2, novoAlarme.getLocalAtendimento());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
}
