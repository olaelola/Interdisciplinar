
package modelo;

import java.util.Date;


public class Pagamento {
    private double valorSinal;
    private double valorTotal;
    private String formaPagamento;
    private String dataPagamento;

    public Pagamento(double valorSinal, double valorTotal, String formaPagamento, String dataPagamento) {
        this.valorSinal = valorSinal;
        this.valorTotal = valorTotal;
        this.formaPagamento = formaPagamento;
        this.dataPagamento = dataPagamento;
    }

    public double getValorSinal() {
        return valorSinal;
    }

    public void setValorSinal(double valorSinal) {
        this.valorSinal = valorSinal;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(String dataPagamento) {
        this.dataPagamento = dataPagamento;
    }
    
    
}
