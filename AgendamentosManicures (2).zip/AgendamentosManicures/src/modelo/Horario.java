
package modelo;

import java.util.Date;
import java.util.Scanner;
import java.util.Vector;


public class Horario {
    private String diaSemana;
    private String data;
    private String hora;
    private boolean reservado;
    

    public Horario(String diaSemana, String data, String hora, boolean reservado) {
        this.diaSemana = diaSemana;
        this.data = data;
        this.hora = hora;
        this.reservado = reservado;
    }
    

    public String getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public boolean isReservado() {
        return reservado;
    }

    public void setReservado(boolean reservado) {
        this.reservado = reservado;
    }
    

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Horario{");
        sb.append("diaSemana = ").append(diaSemana);
        sb.append(", data = ").append(data);
        sb.append(", hora = ").append(hora);
        sb.append('}');
        return sb.toString();
    }
    
    
    
  
}
