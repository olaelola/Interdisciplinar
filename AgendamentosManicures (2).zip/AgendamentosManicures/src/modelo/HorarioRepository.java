
package modelo;

//classe controler responsável pela lógica da minha aplicação

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//classe dao representa 
public class HorarioRepository {

    public boolean insereNovoHorario(Horario novoHorario) {
        String sql = "INSERT INTO TableHorario(DiaSemana, getData, " 
                + "getHora)"
                + " VALUES(?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novoHorario.getDiaSemana());
            transacao.setString(2, novoHorario.getData());
            transacao.setString(3, novoHorario.getHora());
            transacao.setBoolean(4, novoHorario.isReservado());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
}
