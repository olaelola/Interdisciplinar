
package modelo;

//classe controler responsável pela lógica da minha aplicação

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//classe dao representa 
public class ManicureRepository {

    public boolean insereNovaManicure(Manicure novaManicure) {
        String sql = "INSERT INTO TableManicure(Especialidade, Nome, " 
                + "Telefone, Endereco, Email, "
                + "Senha, disponibilidade)"
                + " VALUES(?, ?, ?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novaManicure.getEspecialidade());
            transacao.setString(2, novaManicure.getNome());
            transacao.setString(3, novaManicure.getTelefone());
            transacao.setString(4, novaManicure.getEndereco());
            transacao.setString(5, novaManicure.getEmail());
            transacao.setString(6, novaManicure.getSenha());
            transacao.setBoolean(7, novaManicure.isDisponibilidade());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
}