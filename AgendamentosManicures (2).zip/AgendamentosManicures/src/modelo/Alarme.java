
package modelo;


public class Alarme {
    private String horaUnha;
    private String localAtendimento;

    public Alarme(String horaUnha, String localAtendimento) {
        this.horaUnha = horaUnha;
        this.localAtendimento = localAtendimento;
    }

    public String getHoraUnha() {
        return horaUnha;
    }

    public void setHoraUnha(String horaUnha) {
        this.horaUnha = horaUnha;
    }

    public String getLocalAtendimento() {
        return localAtendimento;
    }

    public void setLocalAtendimento(String localAtendimento) {
        this.localAtendimento = localAtendimento;
    }
    
    
    
}
