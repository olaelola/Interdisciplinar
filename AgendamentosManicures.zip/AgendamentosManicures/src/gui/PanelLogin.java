
package gui;

import Controller.ClienteController;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import gui.PanelManicure;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelo.ClienteRepository;
import modelo.Usuario;
import modelo.UsuarioRepository;

/**
 *
 * @author 0057135
 */
public class PanelLogin extends javax.swing.JPanel {
    private FrameCadastro framePai;
    
    private ClienteController controller;
    
    private ClienteRepository repositor;
    
    
    public PanelLogin(FrameCadastro pai) {
        initComponents();
        
        this.framePai = pai;
    
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        super.paintComponent(g);
        
        /*try {  
            //carregando a imagem de fundo
            Image imagemFundo = ImageIO.read(
                    new File(getClass().
                            getResource("/imagens/fundo_rosa.jpg").
                            getFile()));
            
            //redimen. uma imagem
            imagemFundo = imagemFundo.getScaledInstance(580,440 , 
                    Image.SCALE_DEFAULT);
            
            //"pintando" a imagem no painel
            g.drawImage(imagemFundo, 0, 0, this);
            
            
        } catch (IOException ex) {
            System.err.println("o arquivo esta corrompido");
        }*/
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EntrarBtn = new javax.swing.JButton();
        EntradaTextSenha = new javax.swing.JPasswordField();
        ClienteRadioBtn = new javax.swing.JRadioButton();
        ManicureRadioBtn = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        EntradaTextEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        EntrarBtn.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        EntrarBtn.setForeground(new java.awt.Color(153, 153, 0));
        EntrarBtn.setText("Entrar");
        EntrarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarBtnActionPerformed(evt);
            }
        });

        ClienteRadioBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ClienteRadioBtn.setText("Cliente");

        ManicureRadioBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ManicureRadioBtn.setText("Manicure");
        ManicureRadioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManicureRadioBtnActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Email:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Senha:");

        EntradaTextEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntradaTextEmailActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 0));
        jLabel5.setText("Nail Designer");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(272, 272, 272))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(EntradaTextEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ManicureRadioBtn)
                                    .addComponent(ClienteRadioBtn)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(EntradaTextSenha))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(346, 346, 346)
                        .addComponent(EntrarBtn)))
                .addContainerGap(232, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(EntradaTextEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(73, 73, 73)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(EntradaTextSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ManicureRadioBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClienteRadioBtn)
                .addGap(56, 56, 56)
                .addComponent(EntrarBtn)
                .addGap(82, 82, 82))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void EntrarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarBtnActionPerformed
        
        if(EntradaTextEmail.getText().isEmpty() || EntradaTextSenha.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(this, "É necessário preencher todos os campos", "Preenchimento dos campos", JOptionPane.WARNING_MESSAGE);
            
        }else{
            
            
            String emailUsuario = EntradaTextEmail.getText();
            String senhaUsuario = new String(EntradaTextSenha.getPassword());
            
            Vector<Usuario> usuario = UsuarioRepository.selectAllUsuarios();
            
            for(Usuario u : usuario){
                
                if(u.getEmail().equalsIgnoreCase(emailUsuario) && u.getSenha().equals(senhaUsuario)){
                    
                    JOptionPane.showMessageDialog(this, "Login realizado com sucesso", "Mensagem do Sistema", JOptionPane.WARNING_MESSAGE);
                    
                }else{
                    
                    JOptionPane.showMessageDialog(this, "O login não existe no sistema", "Mensagem do Sistema", JOptionPane.WARNING_MESSAGE);
                    
                }
                
            }
            
        }
            
            
    }//GEN-LAST:event_EntrarBtnActionPerformed

    private void ManicureRadioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManicureRadioBtnActionPerformed

    }//GEN-LAST:event_ManicureRadioBtnActionPerformed

    private void EntradaTextEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntradaTextEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EntradaTextEmailActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ClienteRadioBtn;
    private javax.swing.JTextField EntradaTextEmail;
    private javax.swing.JPasswordField EntradaTextSenha;
    private javax.swing.JButton EntrarBtn;
    private javax.swing.JRadioButton ManicureRadioBtn;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    // End of variables declaration//GEN-END:variables
}
