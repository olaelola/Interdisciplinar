
package modelo;


public class Desing {
    private String modelo;
    private boolean mao_pe;
    private boolean fibra;
    private String formato;
    private String tipo;

    public Desing(String modelo, boolean mao_pe, boolean fibra, String formato, String tipo) {
        this.modelo = modelo;
        this.mao_pe = mao_pe;
        this.fibra = fibra;
        this.formato = formato;
        this.tipo = tipo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public boolean isMao_pe() {
        return mao_pe;
    }

    public void setMao_pe(boolean mao_pe) {
        this.mao_pe = mao_pe;
    }

    public boolean isFibra() {
        return fibra;
    }

    public void setFibra(boolean fibra) {
        this.fibra = fibra;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    
}
