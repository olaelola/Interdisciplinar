
package modelo;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//classe dao representa 
public class DesingRepository {

    public boolean insereNovoDesing(Desing novoDesing) {
        String sql = "INSERT INTO TableDesing(Modelo, Formato, " 
                + "Tipo, Mao_pe, Fibra)"
                + " VALUES(?, ?, ?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novoDesing.getModelo());
            transacao.setString(2, novoDesing.getFormato());
            transacao.setString(3, novoDesing.getTipo());
            transacao.setBoolean(4, novoDesing.isMao_pe());
            transacao.setBoolean(5, novoDesing.isFibra());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
}