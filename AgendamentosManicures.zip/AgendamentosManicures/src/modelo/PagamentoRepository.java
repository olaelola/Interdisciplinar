
package modelo;

//classe controler responsável pela lógica da minha aplicação

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//classe dao representa 
public class PagamentoRepository {

    public boolean insereNovoPagamento(Pagamento novoPagamento) {
        String sql = "INSERT INTO TablePagamento(valorSinal, valorTotal, " 
                + "formaPagamento, dataPagamento)"
                + " VALUES(?, ?, ?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setDouble(1, novoPagamento.getValorSinal());
            transacao.setDouble(2, novoPagamento.getValorTotal());
            transacao.setString(3, novoPagamento.getFormaPagamento());
            transacao.setString(4, novoPagamento.getDataPagamento());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
}
