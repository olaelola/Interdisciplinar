
package modelo;


public class Cliente extends Usuario{
    private String observacoes;
    private String preferencias;

    public Cliente(String observacoes, String preferencias, String nome, String telefone, String endereco, String email, String senha) {
        super(nome, telefone, endereco, email, senha);
        this.observacoes = observacoes;
        this.preferencias = preferencias;
    }
    

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getPreferencias() {
        return preferencias;
    }

    public void setPreferencias(String preferencias) {
        this.preferencias = preferencias;
    }
    
    
    
}
