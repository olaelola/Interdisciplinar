
package modelo;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;
import java.sql.ResultSet;

//classe dao representa 
public class UsuarioRepository {

    public boolean insereNovoUsuario(Usuario novoUsuario) {
        String sql = "INSERT INTO \"TableUsuario\"(nome, telefone, " 
                + "\"endereco\", email, senha)"
                + " VALUES(?, ?, ?, ?, ?)";
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novoUsuario.getTelefone());
            transacao.setString(2, novoUsuario.getEndereco());
            transacao.setString(3, novoUsuario.getSenha());
            transacao.setString(4, novoUsuario.getNome());
            transacao.setString(5, novoUsuario.getEmail());
            
            transacao.execute();
            
            return true;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        
    }
    
    public static Vector<Usuario> selectAllUsuarios(){
        
        Vector<Usuario> usuarioBanco = new Vector<>();
        
        String sql = "SELECT email, senha FROM TableUsuario";
        
        Connection conexao = FabricaBanco.getConexaoPostgres();
        
        try{
            
            PreparedStatement trans = conexao.prepareStatement(sql);
        
            ResultSet tuplas = trans.executeQuery();
            
            while(tuplas.next()){
                
                
                Usuario usuarioBD = new Usuario(tuplas.getString("nome"), tuplas.getString("senha"));
                
                usuarioBanco.add(usuarioBD);
            }
            
        }catch(SQLException e){
            
            e.printStackTrace();
            
        }
        
        return usuarioBanco;
    }
    
}