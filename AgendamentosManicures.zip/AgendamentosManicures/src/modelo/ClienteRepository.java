
package modelo;

//classe controler responsável pela lógica da minha aplicação

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import tool.FabricaBanco;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

//classe dao representa 
public class ClienteRepository {

    public boolean insereNovoCliente(Cliente novoCliente) {
        String sql = "INSERT INTO \"TableCliente\"(observacoes, preferencias) "
                + " VALUES(?, ?)"; // erro na quantidade de parâmetros
        
        Connection conexBD = FabricaBanco.getConexaoPostgres();
        
        try {
            PreparedStatement transacao = conexBD.prepareStatement(sql);
            transacao.setString(1, novoCliente.getObservacoes());
            transacao.setString(2, novoCliente.getPreferencias());
            
            transacao.execute();
            
            System.out.println("deu certo");
            return true;
            
        } catch (SQLException ex) {
            System.out.println("deu errado");
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro: " + ex, "Erro no cadastro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
    }
    
}
