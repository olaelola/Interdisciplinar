
package modelo;


public class Usuario {
    protected String nome;
    protected String telefone;
    protected String endereco;
    protected String email;
    protected String senha;

    public Usuario(String nome, String telefone, String enredeco, String email, String senha) {
        this.nome = nome;
        this.telefone = telefone;
        this.endereco = enredeco;
        this.email = email;
        this.senha = senha;
    }

    public Usuario(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return  nome;
    }

    public String getEmail() {
        return email;
    }

    
}
