package Controller;

import modelo.Usuario;
import modelo.UsuarioRepository;


public class UsuarioController {
    
    private UsuarioRepository repository;
    
    public UsuarioController(){
        repository = new UsuarioRepository();
    }
    public boolean cadastraUsuario(Usuario novoUsuario){
        
        //verificando os dados do novo usuario
        if(novoUsuario == null){
            return false;
        }
        if(novoUsuario.getTelefone().isEmpty() || novoUsuario.getEndereco().isEmpty() || novoUsuario.getSenha().isEmpty() || novoUsuario.getNome().isEmpty() || novoUsuario.getEmail().isEmpty()){
            return false;
        }
        
        UsuarioRepository repository = new UsuarioRepository();
        repository.insereNovoUsuario(novoUsuario);
        boolean retornoBD = repository.insereNovoUsuario(novoUsuario);
        
        return retornoBD;
    }
}