
package tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FabricaBanco {
    private static Connection con;
    
    public static Connection getConexaoPostgres(){
        
        if(con == null){
        try {
            //con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Agendamentos", "postgres", "postgres");
            //con = DriverManager.getConnection("jdbc:postgresql://10.90.24.54/ananogueira_heloa", "aula", "aula");
            con = DriverManager.getConnection("jdbc:postgresql://200.18.128.54:5432/agendamentos", "aula", "aula");
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.err.println("Erro no momento da conexao com o banco");
        }
    }
        return con;
    }
    
}
